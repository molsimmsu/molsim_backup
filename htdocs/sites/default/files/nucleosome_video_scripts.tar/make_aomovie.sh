#!/bin/bash
ffmpeg -sameq -i tgaao/%d.tga -s 800x600 nucl_coltw_AO_3.0.mov
ffmpeg -sameq -i tgaao/%d.tga -s 800x600 nucl_coltw_AO_3.0.wmv
#ffmpeg -b  5000000 -i tga/%d.dat.tga -s 800x600 MmedQ.wmv
#ffmpeg -b  5000000 -i tga/%d.dat.tga -s 800x600 MmedQ.mov
#ffmpeg -b   1000000 -i tga/%d.dat.tga -s 400x300 MlowQ.wmv
#ffmpeg -b   1000000 -i tga/%d.dat.tga -s 400x300 MlowQ.mov
