#!/bin/sh
cd dat;
num=`ls -1 | wc -l`
cd ..
i=$(( $1 + $3 ))
while [ $i -le $4 ]
do
tachyon -trans_vmd -shade_blinn -fullshade -aasamples 10 -rescale_lights 0.5 -add_skylight 0.8 dat/$i.dat -format TARGA -o tgaao/$i.tga
i=$(( $i + $2 ))
done
