#!/bin/bash
mkdir dat
mkdir tgaao
vmd -dispdev none -e movie.tcl
