#!/bin/sh
k=0
echo -n "Number of nodes: "
read nodes
echo -n "Startframe: "
read start
echo -n "Stopframe: "
read stop
while [ $k -lt $nodes ]
do
cat << _EOF_ > aoren${k}.sh
#!/bin/sh
#PBS -N render_string${k}
#PBS -l nodes=1:ppn=8
#PBS -V

cd ${PWD}
./aorender.sh ${k} ${nodes} ${start} ${stop}
_EOF_
qsub -k n aoren$k.sh
k=$(($k+1))
done
