#!/bin/bash
#script converts eps to tiff using GhostView
LIST=$( ls . | grep .eps | sed -e 's/.eps//g');
for n in $LIST;
do
echo "Processing $n ...";
gs -dNOPAUSE -sDEVICE=ppmraw -sOutputFile=temp.ppm -q  -dBATCH  -g1300x900 -r200x200 $n.eps;
pnmcrop -margin=5 temp.ppm > temp2.ppm;
pnmtotiff -lzw temp2.ppm > $n.tif;
rm temp.ppm temp2.ppm;
done
echo "Done!!!"
