#!/bin/bash


l="1 2 4 6 8";


for a in $l;
do
g_energy_4.5.4 -f NVE${a}ps.edr -o energyNVE${a}ps.xvg < enter.txt 
done

