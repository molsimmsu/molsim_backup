#!/bin/bash


l="1 2 4 6 8";


for a in $l;
do
let "b = 500000 * 8 / a"
cat << _EOF_ > NVE${a}ps.mdp
title           = OPLS ARGON NVE equilibration
; Run parameters
integrator      = md            ; leap-frog integrator
nsteps          = $b            ; 
dt              = 0.00$a            ; $a fs
; Output control
nstxout         = 1000           ; save coordinates every 1000 steps
nstvout         = 0              ; do not save velocities
nstenergy       = 1000           ; save energies every 1000 steps
nstlog          = 1000           ; update log file every 1000 steps
; Neighborsearching
ns_type         = grid          ; search neighboring grid cells
nstlist         = 5             ; 10 fs
rlist		= 1.0		; short-range neighborlist cutoff (in nm)
rcoulomb	= 1.0		; short-range electrostatic cutoff (in nm)
rvdw		= 1.0		; short-range van der Waals cutoff (in nm)
;vdwtype		= Switch
;rvdw_switch	= 0.7
; Electrostatics
coulombtype     = cut-off       ; Simple cut-off for long-range electrostatics
; Temperature coupling is off
tcoupl          = no    ; no temperature coupling in NVE
; Pressure coupling is off
pcoupl          = no            ; no pressure coupling in NVE
; Periodic boundary conditions
pbc             = xyz           ; 3-D PBC
; Dispersion correction
DispCorr        = EnerPres      ; account for cut-off vdW scheme
; Velocity generation
gen_vel         = yes           ; assign velocities from Maxwell distribution
gen_temp        = 300           ; temperature for Maxwell distribution
gen_seed        = 7             ; use one seed for distribution
_EOF_
grompp_4.5.4 -f NVE${a}ps.mdp -c em1000.gro -p topol1000.top -o NVE${a}ps.tpr
cat << _EOF_ > NVE${a}ps.sh
#!/bin/sh
#PBS -N ARGON${a}
#PBS -l nodes=1:ppn=4
#PBS -q day
#PBS -V

lamboot -v -ssi boot tm
cd ${PWD}
mpirun C  mdrun_4.5.4_MPI -v -deffnm NVE${a}ps
lamhalt -v $PBS_NODEFILE
_EOF_
qsub NVE${a}ps.sh
done

