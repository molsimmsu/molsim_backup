#!/bin/sh
#PBS -N ARGON_NVE_64
#PBS -l nodes=1:ppn=4
#PBS -q day
#PBS -V

lamboot -v -ssi boot tm 
cd ${PWD}
mpirun C  mdrun_4.5.4_MPI -v -deffnm nve1000
lamhalt -v $PBS_NODEFILE
