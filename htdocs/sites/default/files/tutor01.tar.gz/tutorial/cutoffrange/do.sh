#!/bin/bash


l="0.4 0.8 1 1.5 2";


for a in $l;
do

cat << _EOF_ > NVE${a}coff.mdp
title           = OPLS ARGON NVE equilibration
; Run parameters
integrator      = md            ; leap-frog integrator
nsteps          = 500000        ; 2 * 50000 = 100 ps
dt              = 0.002         ; 2 fs
; Output control
nstxout         = 100           ; save coordinates every 0.2 ps
nstvout         = 0             ; do not save velocities
nstenergy       = 100           ; save energies every 0.2 ps
nstlog          = 100           ; update log file every 0.2 ps
; Neighborsearching
ns_type         = grid          ; search neighboring grid cells
nstlist         = 5             ; 10 fs
rlist           = $a           ; short-range neighborlist cutoff (in nm)
rcoulomb        = 2           ; short-range electrostatic cutoff (in nm)
rvdw            = $a            ; short-range van der Waals cutoff (in nm)
; Electrostatics
coulombtype     = cut-off               ; Particle Mesh Ewald for long-range electrostatics
; Temperature coupling is off
tcoupl          = no    ; modified Berendsen thermostat
; Pressure coupling is off
pcoupl          = no            ; no pressure coupling in NVT
; Periodic boundary conditions
pbc             = xyz           ; 3-D PBC
; Dispersion correction
DispCorr        = EnerPres      ; account for cut-off vdW scheme
; Velocity generation
gen_vel         = yes           ; assign velocities from Maxwell distribution
gen_temp        = 300           ; temperature for Maxwell distribution
gen_seed        = 7             ; generate a random seed
_EOF_
grompp_4.5.4 -f NVE${a}coff.mdp -c em1000.gro -p topol1000.top -o NVE${a}coff.tpr -maxwarn 2
cat << _EOF_ > NVE${a}coff.sh
#!/bin/sh
#PBS -N ARGON_${a}_co
#PBS -l nodes=1:ppn=4
#PBS -q day
#PBS -V

lamboot -v -ssi boot tm
cd ${PWD}
mpirun C  mdrun_4.5.4_MPI -v -deffnm NVE${a}coff
lamhalt -v $PBS_NODEFILE
_EOF_
qsub NVE${a}coff.sh
done

