#!/bin/bash


l="0.4 0.8 1 1.5 2";


for a in $l;
do
if [ $a -ne 1 ]; then
g_energy_4.5.4 -f NVE${a}coff.edr -o energyNVE${a}coff.xvg < enter.txt;
else
g_energy_4.5.4 -f NVE${a}coff.edr -o energyNVE${a}coff.xvg < enter2.txt;
fi 
done

