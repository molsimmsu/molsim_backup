#!/usr/bin/perl
$number=$ARGV[0];
use POSIX;
$box_size=POSIX::ceil($number**(1/3));	#calc. the edge of the cube
printf ("The size of the cub's edge = $box_size\n");
$num=($box_size**3);
printf ("corrected number of atoms = $num\n");
{open(TE,">argon$num.gro") || die "Can't create the main file";
$i=1;$h=0;$r=1;
print(TE "ARGON\n");
print(TE "$num\n");
open(TT,">topol$num.top") ||  die "I can't create topology file";
print TT ("\#include \"oplsaa.ff/forcefield.itp\" \n");
print TT (" \n");
print TT ("[ moleculetype ]\n");
print TT ("; Name            nrexcl\n");
print TT ("ARGON             5 \n");
print TT (" \n");
print TT (" \n");
for ($xi=0; $xi<=($box_size-1); $xi++)
{for ($yi=0; $yi<=($box_size-1); $yi++)
{for ($zi=0; $zi<=($box_size-1); $zi++)
{
$l="GRO";	#name of the group
$ar="Ar";	#type of the atom
$c=0;		#charge
$m=40;		#mass
$x=($xi/$box_size*10);
$y=($yi/$box_size*10);
$z=($zi/$box_size*10);
if ($r==10){$h=$h+1;$r=1}else{$r=$r+1}
print TE sprintf "%5u%5s%5s%5u%8.3f%8.3f%8.3f\n",$h,$l,$ar,$i,$x,$y,$z; 
print TT sprintf "%5u%5s%5u%6s%5s%6u%5u%5u\n",$i,$ar,$h,$l,$ar,$i,$c,$m;
$i=$i+1}}}
print TT ("[ system ]\n");
print TT ("; Name\n");
print TT ("ARGON\n");
print TT (" \n");
print TT ("[ molecules ]\n");
print TT ("; Compound        #mols\n");
print TT ("ARGON     1\n");
close(TT);
close(TE);
}
